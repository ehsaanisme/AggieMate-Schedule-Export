## Privacy Policy

This extension does not collect, store, or transmit any user data. It operates entirely on your local device and accesses only the UC Davis Schedule Builder page to generate a downloadable `.ics` file. No personal information is collected or shared.